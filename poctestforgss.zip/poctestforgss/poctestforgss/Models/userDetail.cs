﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace poctestforgss.Models
{ 
    public class userDetail
    {
        [Key]

        public int userId { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please enter name"), MaxLength(30)]
        [Display(Name = "Student Name")]

        [Column(TypeName ="nvarchar(250)")]
        public string name { get; set; }

       
        [Required(ErrorMessage = "Please enter age")]

        [Column(TypeName = "int")]
        public int age { get; set; }

       
        [Required(ErrorMessage = "Please enter a valid number")]

        [Column(TypeName = "nvarchar(25)")]
        public double number { get; set; }

        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "Please enter Email ID")]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "Email is not valid.")]
        [Column(TypeName = "nvarchar(100)")]
        public string emailId { get; set; }
    }
}
