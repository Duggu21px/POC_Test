﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace poctestforgss.Models
{
    public class userDetailsContext : DbContext
    {
        public userDetailsContext(DbContextOptions<userDetailsContext> options):base(options)
        {
             

        }
        public DbSet<userDetail> userDetails { get; set; }
    }
}
